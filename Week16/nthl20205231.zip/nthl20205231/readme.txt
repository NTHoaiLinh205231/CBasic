Huong dan bien dich:
gcc -o prog bai13-1.c -I /media/sf_CBasic/cgen

De thuc hien cac chuc nang:
Chuc nang 1: ./prog f1 ma-nha-cung-cap tep-du-lieu-dau-vao
Chuc nang 2: ./prog f2 ma-hang tep-du-lieu-dau-vao
Chuc nang 3: ./prog f3 tep-du-lieu-dau-vao