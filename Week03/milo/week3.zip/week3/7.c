#include<stdio.h>

int n, k;
int arr[32];
int max = 1;
int current = 1;
int m[2][32] = {0};

void TRY(int v) {
    if (v == k) {
        if (max < current) {
            max = current;
            for (int i = 0; i < n; i++) m[1][i] = m[0][i];
        }
    } else {
        for (int i = 0; i < n; i++) {
            if (!m[0][i]){
                m[0][i] = 1;
                current *= arr[i];
                TRY(v + 1);
                m[0][i] = 0;
                current /= arr[i];
            }
        }
    }

}

int main() {
    printf("Nhap n, k: ");
    scanf("%d %d", &n, &k);
    printf("Nhap mang:\n");
    for (int i = 0; i < n; i++) scanf("%d", &arr[i]);
    TRY(0);
    for (int i = 0; i < n; i++) {
        if (m[1][i]) printf("%d ", arr[i]);
    }
    printf("\n");
    return 0;
}