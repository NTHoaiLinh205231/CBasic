#include<stdio.h>

int n, M;
int current = 0;

void output(int arr[]) {
    for (int i = 0; i < n; i++) printf("%d ", arr[i]);
    printf("\n");
}

void TRY(int v, int arr[]) {
    if (v == n) {
        if (current == M) output(arr);
    } else {
        for (int i = 1; i < M - n + 2; i++) {
            arr[v] = i;
            current += arr[v];
            if (current <= M) TRY(v + 1, arr);
            current -= arr[v];
        }
    }
}

int main() {
    printf("Nhap n, M: ");
    scanf("%d %d", &n, &M);
    int arr[n];
    TRY(0, arr);
    return 0;
}