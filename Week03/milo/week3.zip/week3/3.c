#include<stdio.h>

int arr[33] = {0};

void TRY(int n) {
    if (n == 0) printf("\n");
    else {
        arr[n] = 0;
        if (arr[n + 1] != arr[n]) {
            printf("%d", arr[n]);
            TRY(n - 1);
        }
        arr[n] = 1;
        if (arr[n + 1] != arr[n]) {
            printf("%d", arr[n]);
            TRY(n - 1);
        }
    }
}

int main() {
    int n;
    printf("Nhap n: ");
    scanf("%d", &n);
    arr[n + 1] = -1;
    TRY(n);
    return 0;
}