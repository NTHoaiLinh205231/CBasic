#include<stdio.h>

int n;
char arr[34] = {'\0'};
int sum = 0;

void TRY(int v) {
    if (v == n) {
        printf("%s\n", arr);
    } else {
        arr[v] = '0';
        TRY(v + 1);
        if (sum > 0){
            arr[v] = '1';
            sum--;
            TRY(v + 1);
            sum++;
        }
    }
}

int main() {
    printf("Nhap k, n: ");
    scanf("%d %d", &sum, &n);
    TRY(0);
    return 0;
}