#include<stdio.h>

int n;

void TRY(int k, int *p) {
    if (k == n + 2) {
        for (int i = 2; i < n + 2; i++) printf("%d", p[i]);
        printf("\n");
    } else {
        p[k] = 0;
        TRY(k + 1, p);
        p[k] = 1;
        if (!(p[k - 1] == 0 && p[k - 2] == 1)) TRY(k + 1, p);
    }
}

int main() {
    printf("Nhap n: ");
    scanf("%d", &n);
    int arr[34] = {0};
    arr[0] = -1;
    arr[1] = -1;
    int *p = arr;
    TRY(2, p);
    return 0;
}