#include<stdio.h>

int n;
int max = 0;
int arr[32];
int m[32] = {0};
int x[2][32];

void TRY(int v) {
    if (v == n) {
        int current = 0;
        for (int i = 1; i < n - 1; i++) {
            if (x[0][i] > x[0][i - 1] && x[0][i] > x[0][i + 1]) {
                current++;
            }
        }
        if (max < current) {
            max = current;
            for (int i = 0; i < n; i++) x[1][i] = x[0][i];
        }
    } else {
        for (int i = 0; i < n; i++) {
            if (!m[i]) {
                x[0][v] = arr[i];
                m[i] = 1;
                TRY(v + 1);
                m[i] = 0;
            }
        }
    }
}

int main() {
    printf("Nhap n: ");
    scanf("%d", &n);
    printf("Nhap mang:\n");
    for (int i = 0; i < n; i++) scanf("%d", &arr[i]);
    TRY(0);
    if (max > 0) {
        for (int i = 0; i < n; i++) printf("%d ", x[1][i]);
        printf("%d\n", max);
    } else printf("%d\n", max);
    return 0;
}