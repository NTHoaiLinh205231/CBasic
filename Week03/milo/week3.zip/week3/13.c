#include<stdio.h>
#include<stdlib.h>

int x[9][9] = {
    {0, 0, 0, 8, 0, 1, 0, 0, 0},
    {0, 0, 0, 0, 0, 0, 0, 4, 3},
    {5, 0, 0, 0, 0, 0, 0, 0, 0},
    {0, 0, 0, 0, 7, 0, 8, 0, 0},
    {0, 0, 0, 0, 0, 0, 1, 0, 0},
    {0, 2, 0, 0, 3, 0, 0, 0, 0},
    {6, 0, 0, 0, 0, 0, 0, 7, 5},
    {0, 0, 3, 4, 0, 0, 0, 0, 0},
    {0, 0, 0, 2, 0, 0, 6, 0, 0}
};

void printSolution() {
    for (int i = 0; i < 9; i++) {
        for (int j = 0; j < 9; j++) printf("%d ", x[i][j]);
        printf("\n");
    }
    printf("\n");
}

int check(int v, int r, int c){
    for (int i = 0; i < 9; i++) {
        if (x[r][i] == v) return 0;
        if (x[i][c] == v) return 0;
    }
    int I = r / 3;
    int J = c / 3;
    for (int i  = 3 * I; i < 3 * I + 3; i++)
        for (int j = 3 * J; j < 3 * J + 3; j++)
            if (x[i][j] == v) return 0;
    return 1;
}

int TRY(int r, int c){
    if (r == 8 && c == 9) return 1;
    if (c == 9) {
        r++;
        c = 0;
    }
    if (x[r][c] == 0) {
        for (int v = 1; v <= 9; v++)
            if (check(v, r, c)) {
                x[r][c] = v;
                if (TRY(r, c + 1)) return 1;
            }
        x[r][c] = 0;
    } else return TRY(r, c + 1);
    return 0;
}


int main() {
    if (TRY(0, 0)) printSolution();
    else printf("No solution\n");
    return 0;
}