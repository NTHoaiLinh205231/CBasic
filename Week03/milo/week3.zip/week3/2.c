#include<stdio.h>
#include<math.h>

void move(int n, char source, char destination, char auxiliary) {
    if (n == 1) printf("%c => %c\n", source, destination);
    else {
        move(n - 1, source, auxiliary, destination);
        move(1, source, destination, auxiliary);
        move(n - 1, auxiliary, destination, source);
    }
}

int main() {
    int n;
    printf("Nhap so dia: ");
    scanf("%d", &n);
    int steps = (int) pow(2, n) - 1;
    printf("So buoc can thuc hien: %d\n", steps);
    if (steps > 1000) {
        printf("Ban co muon xem chi tiet cac buoc?(y/n) ");
        char check;
        scanf(" %c", &check);
        if (check == 'y') move(n, 'A', 'B', 'C');
    } else move(n, 'A', 'B', 'C');
    return 0;
}