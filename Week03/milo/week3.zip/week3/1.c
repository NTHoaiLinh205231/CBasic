#include<stdio.h>

int C[30][30] = {0};

int combination(int k, int n) {
    if (k == 0 || k == n) C[k][n] = 1;
    if (!C[k][n]) {
        C[k][n] = combination(k, n - 1) + combination(k - 1, n - 1);
    }
    return C[k][n];
}

int main() {
    int k, n;
    printf("Nhap k, n: ");
    scanf("%d %d", &k, &n);
    printf("%d\n", combination(k, n));
    return 0;
}