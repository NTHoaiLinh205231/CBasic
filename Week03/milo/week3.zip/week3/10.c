#include<stdio.h>

int n;
int arr[2][32] = {0};
int m[32] = {0};
int check = 0;

void output() {
    for (int i = 1; i <= n; i++) {
        if (m[i]) printf("%d ", arr[1][i]);
    }
    printf("\n");
}

int TRY(int v) {
    for (int i = 1; i <= n; i++) {
        if (v == n + 1) {
            output();
            check++;
            return 1;
        }
        if (!m[i]) {
            arr[1][v] = arr[0][i];
            arr[1][n + 1] = arr[0][v] + 1;
            m[i] = 1;
            if ((arr[1][v] + arr[1][v - 1]) % 2 == 1) TRY(v + 1);
            m[i] = 0;
        }
    }
    return check;
}

int main() {
    printf("Nhap n: ");
    scanf("%d", &n);
    printf("Nhap mang:\n");
    for(int i = 1; i <= n; i++) scanf("%d", &arr[0][i]);
    arr[1][0] = arr[0][1] - 1;
    if (!TRY(1)) printf("NO\n");
    return 0;
}