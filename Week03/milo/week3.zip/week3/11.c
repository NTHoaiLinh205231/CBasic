#include<stdio.h>

int x[32] = {'\0'};
int n;

void printSolution() {
    for (int i = 1; i <= n; i++) printf("%d", x[i]);
    printf("\n");
}

int check(int k, int v) {
    if (k == 1) return 1;
    for (int i = 1; i <= k - 1; i++) {
        if (x[i] == v) return 0;
        if (x[i] + i == v + k) return 0;
        if (x[i] - i == v - k) return 0;
    }
    return 1;
}

void TRY(int k) {
    for (int v = 1; v <= n; v++) {
        if (check(k, v)) {
            x[k] = v;
            if (k == n) printSolution();
            else TRY(k + 1);
        }
    }
}

int main() {
    printf("Nhap n: ");
    scanf("%d", &n);
    TRY(1);
    return 0;
}