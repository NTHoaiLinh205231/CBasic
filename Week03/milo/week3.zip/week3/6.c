#include<stdio.h>

void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

void sort(int arr[], int length) {
    for (int i = 0; i < length - 1; i++)
        for (int j = i + 1; j < length; j++)
            if (arr[i] > arr[j])
                swap(&arr[i], &arr[j]);
}

int main() {
    int n;
    printf("Nhap n: ");
    scanf("%d", &n);
    int arr[n];
    printf("Nhap say so:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
    sort(arr, n);
    int k;
    printf("Nhap k: ");
    scanf("%d", &k);
    for (int i = n - k; i < n; i++) printf("%d ", arr[i]);
    printf("\n");
    return 0;
}